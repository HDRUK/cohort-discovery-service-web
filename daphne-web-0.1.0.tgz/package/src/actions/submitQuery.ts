"use server";

import { RuleGroupType } from "react-querybuilder";
import { apiPost } from "../lib/apiClient";
import { API_ROUTES } from "../lib/apiRoutes";
import { CreateQuery, CreateQueryPost, ApiResponse } from "../types/api";

const submitQuery = async (
  query: RuleGroupType,
  queryName: string,
  collection_filter?: string[]
): Promise<ApiResponse<CreateQuery>> => {
  return await apiPost<ApiResponse<CreateQuery>, CreateQueryPost>(
    API_ROUTES.queries,
    {
      name: queryName,
      definition: query,
      task_type: "a",
      ...(collection_filter && { collection_filter }),
    }
  );
};

export default submitQuery;
