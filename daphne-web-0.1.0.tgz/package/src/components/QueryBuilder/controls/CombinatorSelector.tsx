"use client";

import { Select, MenuItem } from "@mui/material";
import { ValueSelectorProps } from "react-querybuilder";

const CombinatorSelector = ({
  options,
  value,
  className,
  handleOnChange,
}: ValueSelectorProps) => {
  return (
    <Select
      value={value}
      onChange={(e) => handleOnChange(e.target.value)}
      className={className}
      size="small"
    >
      {options.map((opt) => (
        <MenuItem key={opt.name} value={opt.name}>
          {opt.label}
        </MenuItem>
      ))}
    </Select>
  );
};

export default CombinatorSelector;
