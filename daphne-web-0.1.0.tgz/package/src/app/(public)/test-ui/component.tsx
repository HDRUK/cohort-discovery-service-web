"use client";

import { Button } from "@hdruk/ui";

export default function Component() {
  return (
    <b>
      <Button>hi</Button>
    </b>
  );
}
